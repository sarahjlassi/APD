# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Allure Backend Theme Project',
    'category': "Themes/Backend",
    'version': '1.0',
    'license': 'OPL-1',
    'summary': 'Flexible, Powerful and Fully Responsive Customized Backend Theme with many features(Favorite Bar, Vertical Horizontal Menu Bar, Night Mode, Tree view of Menu and Sub menu, Fuzzy search for apps, Display density) in Community Edition.',
    'description': """ Allure theme with project
    """,
    'author': 'Synconics Technologies Pvt. Ltd.',
    'depends': ['project','allure_backend_theme'],
    'website': 'www.synconics.com',
    'images': [
        'static/description/main_screen.png',
        'static/description/allure_screenshot.png',
    ],
     'assets': {
        'web.assets_qweb': [
            'allure_backend_theme_project/static/src/xml/base.xml',
        ],

    },
    'price': 0.0,
    'currency': 'USD',
    'installable': True,
    'auto_install': False,
    'bootstrap': True,
}
